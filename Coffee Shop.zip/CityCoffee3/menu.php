<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="order.css" />
    <link rel="stylesheet" href="survey.css" />
    <title>City Coffee House Events</title>
   <meta charset="UTF-8"/>
</head>
	<header>
    <img src="images/logocup.png" alt="logocup" align="left";/>
    <h1>City Coffee House</h1>
    </header>
    <nav>
      <ul class="nav">
           <li><a href="index.html">Home</a></li>&nbsp;&nbsp;&nbsp;
            <li><a href="menu.html">Menu</a></li>&nbsp;&nbsp;&nbsp;
            <li><a href="event.html">Events</a></li>&nbsp;&nbsp;&nbsp;
            <li><a href="reservation.html">Event Registration</a></li> &nbsp;&nbsp;&nbsp;
            <li><a href="order.php">Order Now</a></li> &nbsp;&nbsp;&nbsp;
            <li><a href="survey.php">Survey</a></li>
      </ul>
    </nav>
</html>
