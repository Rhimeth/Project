<!DOCTYPE html>
<html lang="en">
	<head>
	<style>
	table, th, td{
		border: 1px solid black;
	}
	</style>
	</head>
	<head>
		<meta charset="UTF-8">
		<title>City Coffee House Events</title>
		<link rel="stylesheet" href="order.css">
	</head>
	<body>
	<div id="nav">
	<header>
		<h1>City Coffee House</h1>
	</header>
		<div id="nav1">
	<nav>
		<ul class="nav">
			<a href="index.html">Home</a> &nbsp
			<a href="menu.html">Menu</a> &nbsp
			<a href="events.html">Events</a> &nbsp
			<a href="reservation.html">Reservation</a> &nbsp
			<a href="order now.html">Order Now</a> &nbsp
			<a href="survey.html">Survey</a> &nbsp
		</div>
		</ul>
	</nav>
	<main>
		<h2>List of Events at City Coffee Shop</h2>
			<img src="upevents.png" width="550" height="100">
		<table style="width:100%;text-align:left;">
			<tr style="background-color:#D2B48C;">
				<th>Date</th>
				<th>Time</th>
				<th>Event</th>
				<th>Guest</th>
				<th>Sponsor</th>
				<th>Frequency</th>
				<th>Detail</th>
			</tr>
			<tr style="background-color:#c99608;">
				<td>March 10th</td>
				<td>5:00PM</td>
				<td>Book Review</td>
				<td>Robert Walser's</td>
				<td>Virginia Books Club</td>
				<td>Monthly</td>
				<td>Join the Community Bookstore for an event</td>
			</tr>
			<tr style="background-color:#ebd391;">
				<td>March 11th</td>
				<td>3:00PM</td>
				<td>Movie Review</td>
				<td>Dan J. Johnson</td>
				<td>Virginia Movie Club</td>
				<td>Monthly</td>
				<td>Safer at Home</td>
			</tr>
			<tr style="background-color:#c99608;">
				<td>March 12th</td>
				<td>Music Evening</td>
				<td>Melanie Morris</td>
				<td>6:00PM</td>
				<td>Richmond Music Club</td>
				<td>Weekly</td>
				<td>Melanie Morris entertains with her melodic folk style</td>
			</tr>
			<tr style="background-color:#ebd391;">
				<td>March 13th</td>
				<td>8:00PM</td>
				<td>Story Night</td>
				<td>Mark Eitzel</td>
				<td>Chesterfield Library</td>
				<td>Weekly</td>
				<td>Tahoe Greg is back from his tour. New songs. New stories</td>
			</tr>
		</table>
	<p>
		<dd>
			All the events are free and required pre-registration due to limited seating. 
			Join and reserve your seat today.
		</dd>
	</p>
		<div>
		12010 Broad Street,<br/>
		Richmond, VA 23234<br/>
		1-888-555-5555<br/><br/>
		</div>
	</main>
		<footer class="foot">
			Copyright © 2021 City Coffee House<br>
			<a href="">firstname@lastname.com</a>
		</footer>
	</div>
	</body>
</html>