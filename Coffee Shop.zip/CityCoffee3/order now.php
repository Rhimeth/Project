<!DOCTYPE html>
<html lang="en">
<?php
	include_once 'menu.php';
?>
	<head>
		<link rel="stylesheet" href="style1.css">
		<title>MidTerm</title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet"href="style.css">
	<style>
.container {
  position: relative;
}

.bottomleft {
  position: relative;
  bottom: 30px;
}

img { 
  height: auto;
}
	</style>
	</head>
		<h1 "text-align:left;">
			<img src="logocup.png" alt="Coffee cup" width="150" height="150;"image="left;">
		City Coffee House
		</h1>
	<nav>
		<ul class="nav">
			<a href="index.php">Home</a> &nbsp
			<a href="menu.html">Menu</a> &nbsp
			<a href="events.html">Events</a> &nbsp
			<a href="reservation.html">Reservation</a> &nbsp
			<a href="order now.html">Order Now</a> &nbsp
			<a href="survey.html">Survey</a> &nbsp
		</div>
		</ul>
	</nav>
	<main>
		<h2>Welcome to Order Now</h2>
		<form>
			<label for="name">Customer's Name:</label>
			<input type="text" id="name" name="name"><br>
			<label for="street address">Street Address:</label>
			<input type="text" id="street address" name="street address"><br>
			<label for="city">City:</label>
			<input type="text" id="city" name="city">
			<label for="state">State:</label>
			<input type="text" id="state">
			<label for="zip">Zip:</label>
			<input type="text" id="zip">
		</form>
		<table style="width:100%;text-align:left;">
			<tr style="background-color:#D2B48C;">
				<th>Product</th>
				<th>Description</th>
				<th>Price</th>
				<th>Quantity</th>
			</tr>
				<td>Just Java</td>
				<td>Regular house blend, decaffeinated coffee, or flavor of the day.Endless Cup</td>
				<td>$3.00</td>
				<td>
					<input type="text" id="quantity" name="quantity">
				</td>
			</tr>
				<td>Cafe au Lait</td>
				<td>House blended coffee infused into a smooth, steamed milk. Single</td>
				<td>$4.00</td>
				<td>
					<input type="text" id="quantity" name="quantity">
				</td>
			</tr>
				<td>Cafe au Lait</td>
				<td>House blended coffee infused into a smooth, steamed milk. Double</td>
				<td>$5.00</td>
				<td>
					<input type="text" id="quantity" name="quantity">
				</td>
			</tr>
				<td>Iced Cappuccino</td>
				<td>Sweetened espresso blended with icy-cold milk and served in a chill glass. Single</td>
				<td>$5.00</td>
				<td>
					<input type="text" id="quantity" name="quantity">
				</td>
			</tr>
				<td>Iced Cappuccino</td>
				<td>Sweetened espresso blended with icy-cold milk and served in a chill glass. Double</td>
				<td>$6.50</td>
				<td>
					<input type="text" id="quantity" name="quantity">
				</td>
			</tr>
		</table>

		<p><b>Payment Method</b></p>
		<form>
			<input type="radio" id="name" name="Visa" value="Visa">
			<label for="Visa">Visa</label><br>
			<input type="radio" id="name" name="Master Card" value="Master Card">
			<label for="Master Card">Master Card</label><br>
			<input type="radio" id="name" name="Discover" value="Discover">
			<label for="Discover">Discover</label><br>
			<input type="radio" id="name" name="Check" value="Check">
			<label for="Check">Check</label><br>
			<input type="submit" name="submit" value="Submit Order">
			<input type="reset" name="reset" value="Clear Order Form">
		</form> 
<?php
	include_once 'footer.php';
?>		
</html>