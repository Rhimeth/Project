<?php
        include_once 'menu.php';
?>
<body>

    <div class="heading">
        <h2>Welcome to Order Now</h2>
    </div>

    <div class="wrap">
        <form action="#">
            <div class="customer_details">
                <p>
                <label for="name">Customer Name: </label>
                <input type="text" name="name" id="name"> <br>
                </p>

                <p>
                <label for="address">Street Address: </label>
                <input type="text" name="address" id="address"> <br>
                </p>

                <p>
                    <label for="city">City: </label>
                    <input type="text" name="city" id="city">

                    <label for="name">State: </label>
                    <input type="text" name="state" id="state">

                    <label for="name">Zip: </label>
                    <input type="text" name="zip" id="zip">
                </p>

                
            </div>
        
            <div class="order_details">
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Just Java</td>
                            <td>Regular house blend, decaffeinated coffee, or flavour of the day.Endless cup</td>
                            <td>$3.50</td>
                            <td>
                                <input type="text" name="qty" id="qty">
                            </td>
                        </tr>
                        <tr>
                            <td>Cafe au Lait</td>
                            <td>House blend coffee infused into a smooth, steamed milk.Single</td>
                            <td>$4.00</td>
                            <td>
                                <input type="text" name="qty" id="qty">
                            </td>
                        </tr>
                        <tr>
                            <td>Cafe au Lait</td>
                            <td>House blend coffee infused into a smooth, steamed milk. Double</td>
                            <td>$5.00</td>
                            <td>
                                <input type="text" name="qty" id="qty">
                            </td>
                        </tr>
                       
                        <tr>
                            <td>Iced Cappuccino</td>
                            <td>Sweetened expresso blended with icy-cold milk and served into a chilled glass. Single</td>
                            <td>$5.00</td>
                            <td>
                                <input type="text" name="qty" id="qty">
                            </td>
                        </tr>
                        <tr>
                            <td>Just Java</td>
                            <td>Sweetened expresso blended with icy-cold milk and served into a chilled glass. Double</td>
                            <td>$6.50</td>
                            <td>
                                <input type="text" name="qty" id="qty">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        
            <div class="payment">
                <h4>Payment Method</h4>

                <input type="radio" id="visa" name="payment" value="visa">
                <label for="visa">Visa</label><br>

                <input type="radio" id="master" name="payment" value="master_card">
                <label for="master">Master Card</label><br>

                <input type="radio" id="discover" name="payment" value="discover">
                <label for="discover">Discover</label>
                <br>
                <input type="radio" id="check" name="payment" value="check">
                <label for="check">Check</label>

            </div>
        
            <div class="buttons">
                <input type="submit" value="Submit Order">
                <input type="submit" value="Clear Order Form">
            </div>
        </form>
    </div>

    
<?php
        include_once 'footer.php';
?>