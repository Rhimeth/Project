<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="order.css" />
    <link rel="stylesheet" href="survey.css" />
    <title>City Coffee House Events</title>
   <meta charset="UTF-8"/>
<br /><br />
    <footer>
		Copyright © 2021 City Coffee House<br>
		<a href="">firstname@lastname.com</a>
    </footer>
   </div>
   </main>
</body>
</html>