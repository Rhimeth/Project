<!DOCTYPE html>
<html lang="en">
	<head>
	<style>
		<meta charset="UTF-8">
		<title>City Coffee House Events</title>
		<link rel="stylesheet" href="order.css">
	</head>
	<body>
	<div id="nav">
	<header>
		<h1>City Coffee House</h1>
	</header>
		<div id="nav1">
	<nav>
		<a href="index.html">Home</a> &nbsp;
		<a href="menu.html">Menu</a> &nbsp;
		<a href="events.html">Events</a> &nbsp;
		<a href="reservation.html">Reservation</a> &nbsp;
		</div>
	</nav>
	<main>
		<h2>Reserve Your Event</h2>
		<img src="reserve.jpg" alt="Event Reservation" width="600" height="150">
		<form>
			<label for="Event Name">Event Name:</label>
			<input type="text" id="Event Name" name="Event Name"><br>
			<label for="Sponsor">Sponsor:</label>
			<input type="text" id="Sponsor" name="Sponsor"><br>
			<label for="Guest">Guest:</label>
			<input type="text" id="Guest" name="Guest"><br>
			<label for="Detail">Detail:</label>
			<input type="Please enter details of the event" id="Detail" name="Detail"><br>
			<label for="Frequency">Frequency:</label>
			<select id="Frequency" name="Frequency">
				<option value="Daily">Daily</option>
				<option value="Weekly">Weekly</option>
				<option value="Monthly">Monthly</option>
				<option value="Yearly">Yearly</option>
			</select>
			<br>
			<label for="Event Start Date">Event Start Date:<label>
			<input type="date" id="Event Start Date" name="Event Start Date"><br>
			<label for="Enter your email">Enter your email:<label>
			<input type="text" id="Enter your email" name="Enter your email"><br>
			<input type="checkbox" id="E-mail" name="E-mail" value="E-mail">
			<label for="E-mail">E-mail</label>
			<input type="checkbox" id="WhatsApp" name="WhatsApp" value="WhatsApp">
			<label for="WhatsApp">WhatsApp</label><br>
			<input type="checkbox" id="Mobile" name="Mobile" value="Mobile">
			<label for="Mobile">Mobile</label>
			<input type="checkbox" id="In App Chat" name="In App Chat" value="In App Chat">
			<label for="In App Chat">In App Chat</label><br>
			<input type="submit" value="Submit Request">
			<input type="reset" value="Clear Form">
		</form>
		</div>
	</main>
	</head>
</html>