<!DOCTYPE html>
<html lang="en">
	<head>
		<title>City Coffee House</title>
		<link rel="stylesheet"href="order.css">
	<style>
.container {
  position: relative;
}

.bottomleft {
  position: relative;
  bottom: 30px;
}

img { 
  height: auto;
}
	</style>
	</head>
	<head>
	<body style="background-color: #FCEBB6;">
	<div id="wrapper">
	<header>
		<h1 "text-align:left;">
			<img src="logocup.png" alt="Coffee cup" width="150" height="150;"image="left;">
		City Coffee House
		</h1>
	</header>
		<div id="nav1">
	<nav>
		<ul class="nav">
			<a href="index.html">Home</a> &nbsp
			<a href="menu.html">Menu</a> &nbsp
			<a href="events.html">Events</a> &nbsp
			<a href="reservation.html">Reservation</a> &nbsp
			<a href="order now.html">Order Now</a> &nbsp
			<a href="survey.html">Survey</a> &nbsp
		</div>
		</ul>
	</nav>
	<main>
	<img src="coffeeshop.jpg" alt="Coffee" width="400" height="300;">
		<h2> Relax at City Coffee</h2>
		<dl>
			<p>
			<dd>
				We&#8217;re a little out of the way, but take a drive down Garrett Bay Road to today!
				Indulge in our locally roasted free-trade coffee and home-made pastries. 
				You’ll feel right at home at City Coffee!
			</dd>
			</p>
		<h3>City Coffee Bar features:</h3>
		<ul>
			<li>Specialty Coffee and Tea</li>
			<li>Bagels, Muffins, and Organic Snacks</li>
			<li>Music and Poetry Readings</li>
			<li>Open Mic Night</li>
		</ul>
		<div>
		12010 Broad Street,<br/>
		Richmond, VA 23234<br/>
		1-888-555-5555<br/><br/>
		</div>
		</dl>
	</main>
		<br>
		<footer class="foot">
			Copyright © 2021 City Coffee House<br>
			<a href="">firstname@lastname.com</a>
		</footer>
	</div>
	</body>
</html>	
