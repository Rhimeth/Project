<html>

    <head>

        <link rel="stylesheet" href="css/style.css">

    </head>

<body>



<h1>Your job application is submitted</h1>

<h2 >Personal Infromation</h2>

<table border=1>

  <tr>

    <th>prefix</th>

    <th>Name</th>

    <th>Street</th>

    <th>City</th>

  </tr>
 <?php
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }
 }
 ?>

  <tr>

    <td>

    <?php

        $g = ("gender");

        if ($g = "male") {

            echo "Mr";

        }

        else {

            echo "Ms";

        }

    ?>

    </td>
 
    <td><?php echo["name"] ?></td>

    <td><?php echo $_POST["streetaddress"]; ?></td>

    <td><?php echo $_POST["city"]; ?></td>

  </tr>

</table>

<h1>Your requierd salary is <?php echo $_POST["range"]; ?> </h1>

<br>

<br>

<br>

<br>

<br>

<h2>your prefered contact seleted is <?php echo $_POST["checkbox"]; ?> </h2>

/*
Chidubem Ntiwunka-Ifeanyi
V00623707
cnti3707@students.vsu.edu
*/

</body>

</html>

