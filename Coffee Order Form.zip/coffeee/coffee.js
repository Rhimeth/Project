function getCost(){
	var frenchQty = document.getElementById('french').value;
	var hazelnutQty= document.getElementById('hazelnut').value;
	var colombianQty = document.getElementById('colombian').value;
	
	var frenchPrice = 3.49;
	var hazelnutPrice = 3.95
	var colombianPrice = 4.49;
	
	var french = frenchQty * frenchPrice;
	var hazelnut = hazelnutQty * hazelnutPrice;
	var colombian = colombianQty *colombianPrice;
	
	var totalCost = french + hazelnut + colombian;
	
	document.getElementById('cost').value = '$' + totalCost;