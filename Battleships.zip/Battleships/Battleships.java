/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package batlleships;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Dubem
 */
public class Battleships {

    private static char Placement;
    private static char[][] Board;
    private static char Position;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Prints out first messages to player
        System.out.println("WELCOME TO BATTLESHIPS!");
        
        //Declaring variables
        int BoardLength = 6;
        Board = new char[BoardLength][BoardLength];
        char Ship = 'x';
        char Water = '-';
        char Hit = 'h';
        char Miss ='m';
        int ShipNumber = 5;
        
        //Creates GameBoard array
        char[][] GameBoard = createBoard(Ship, Water, BoardLength, ShipNumber);
        PrintBoard(GameBoard,Water, Ship);
        
        //Declare any undtected ships equals to the number of ships
        int UndetectedShipNumber = ShipNumber;
        
        //while loop created to locate any undetected ships by taking the user input, if they input hits an undetected ships it updates to reduce the number of undetected ships
        while (UndetectedShipNumber > 0){
            int[] GuessCoordinates = UserCoordinates(BoardLength, GameBoard);
            char GetTarget = 0;
            
            char LocationUpdate = GetTarget(GuessCoordinates, GameBoard, Water, Ship, Hit, Miss);
            
            if(LocationUpdate == Hit){
                UndetectedShipNumber--;
            }
            //Displays updated GameBoard
            GameBoard = UpdateBoard(LocationUpdate, GuessCoordinates, GameBoard);
            PrintBoard(GameBoard, Water, Ship);
        }
    }

    //Creates the Board for BattleShips
    private static char[][] createBoard(char Ship, char Water, int BoardLength, int ShipNumber) {
        char [][] GameBoard = new char[BoardLength][BoardLength];
        
        /**for(char[] row : Board){
        Arrays.fill(row, Water);
        }**/
        //Fills the board with water
        for (char[] Board : Board) {
            for (int j = 0; j < Board.length; j++) {
                Board[j] = Water;
            }
        }
        
        return PlacedShips(Board, Ship, Water, ShipNumber);
    }
    
    //Creates and places ships on the Board
    private static char[][] PlacedShips(char[][] Board, char Ship, char Water, int ShipNumber) {
        //Declares variables
        int PlacedShips = 0;
        int BoardLength = Board.length;
        
        //While loop for getting ship coordinates and placing ships on water
        while (PlacedShips < ShipNumber){
            int[] Location = generateShipCoordinates(BoardLength);
            int x = Location[0];
            int y = Location[1];
            char Placement = Board[x][y];
        
            if (Placement == Water){
                Board[Location[0]][Location[1]] = Ship;
                PlacedShips++;
            }
        }
        return Board;
    }
    
    //Method for creating the coordiantes of ships 
    private static int[] generateShipCoordinates(int BoardLength) {
        //Declares variables and Coordinates array
        int[] Coordinates = new int[2];
        int i;
        
        //For loop for randomly creating ships coordinates
        for (i = 0; i < Coordinates.length; i++){
            Coordinates[i] = new Random().nextInt(BoardLength); 
        }
        return Coordinates;
    }

    //Method to print out the BattleShips Board
    private static void PrintBoard(char[][] Board, char Water, char Ship) {
        //Assign the length of board variable to BoardLength variable
        int BoardLength = Board.length;
        
        //Print out the BoardLength
        System.out.print("  ");
        for (int i = 0; i < BoardLength; i++){
            System.out.print(i + 1 + " ");
        }
        //Prints out the Rows accoring to the board length
        System.out.println();
        for (int Row = 0; Row < BoardLength; Row++){
            System.out.print(Row + 1 + " ");
            //Prints out the Column of the Board according to BoardLength
            for (int Column = 0; Column < BoardLength; Column++){
                char Position = Board[Row][Column];
                if (Position == Ship){
                    System.out.print(Water + " ");
                }
                else{
                    System.out.print(Position + " ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }
    
    //Method to get the user's coordinate input 
    private static int[] UserCoordinates(int BoardLength, char[][] Board) {
        int Row;
        int Column;
        
        //Do loop for taking in the user's input for row guess
        do{
            System.out.print("Row: ");
            Row = new Scanner(System.in).nextInt();
        }
        while (Row < 0|| Row > BoardLength + 1);
        
        //Do loop for taking in the user's input for column guess
        do{
            System.out.print("Column: ");
            Column = new Scanner(System.in).nextInt();
        }
        while (Column < 0|| Column > BoardLength + 1);
        
        return new int[] {Row - 1, Column-1};

    }
    
    //Method that displays the results of the users guess or input
    private static char GetTarget(int[] GuessCoordinates, char[][] Board1, char Water, char Ship, char Hit, char Miss) {
        //Decalres variables
        int Row = GuessCoordinates[0];
        int Column = GuessCoordinates[1];
        String Message;
        
        char Target = Board[Row][Column];
        
        //Dipslays the results of the users input if a ship is hit
        if (Target == Ship){
            Message = "BOOOM!";
            Target = Hit;
        }
        //Displays results of users input if water is hit
        else if (Target == Water){
            Message = "UNLUCKYY!";
            Target = Miss;
        }
        else{
            Message = "ALREADY HIT!";
        }
        System.out.print(Message);
        
        return Target;
    }
    
    //Method that updates the Board after user input has been recived
    private static char[][] UpdateBoard(char LocationUpdate, int[] GuessCoordinates, char[][] Board) {
        int Row = GuessCoordinates[0];
        int Column = GuessCoordinates[1];
        
        Board[Row][Column] = LocationUpdate;
        
        return Board;
    }


    private static char GetTarget() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static char[][] UpdateBoard() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
