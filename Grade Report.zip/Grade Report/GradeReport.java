/*
 *Homework 4
 *Chidubem Ntiwunka-Ifeanyi
 *10/15/2020
 *Code used to calculate Grades for multiple students
 */
package javaapplication10;

import java.util.Scanner;

public class GradeReport {
//Declaring variable
    public static void main(String[] args) {
        //Creating Scanner class to take in input from user
        Scanner input = new Scanner(System.in);
        //Initializing objects for GradeReport class
        int Num = 1;
        double Score = 0;
        char Grade = 'x';
        String Name;
        int Quit = -1;
        String Report = "";
        double HighestGrade = Double.MIN_VALUE;
        double LowestGrade = Double.MAX_VALUE;
        double GradeSum = 0;
        String Average;
        double Maximum = 0;
        double Minimum;
        
        //Creating indefinite while loop
        while (true) {
            //Taking in input from the user
            System.out.print("Enter name for student " + Num + " or " + Quit + " to quit: ");
            Name = input.next();
            
            //Creating if statement to break while loop
            if (Name.equals("-1")) {
                break;
            }
            
            //Taking in input from the user
            System.out.print("Enter grade for student " + Num + " or " + Quit + " to quit: ");
            Score = input.nextInt();

            //While loop for Score and Num variables
            while (Score == -1) {
                Score = scan.nextDouble();
                Grade += Score;
                Num++;
                break;
            }
            
            //if statement for Grade and GradeSum variables
            if (Grade > HighestGrade)
                HighestGrade = Grade;
                if (Grade < LowestGrade)
                LowestGrade = Grade;
                GradeSum += Grade;

            Num += 1;
            
            //if statement used to assign Grade
            if (Score >= 90) {
                Grade = 'A';
            } else if (Score >= 80) {
                Grade = 'B';
            } else if (Score >= 70) {
                Grade = 'C';
            } else if (Score >= 60) {
                Grade = 'D';
            } else {
                Grade = 'F';
            }
            Report = Report  + "\n" + Name + " =" + " " + Grade;
        }
            System.out.println(Report);
            
            System.out.println("Average: " + GradeSum/Num);
    }
}
