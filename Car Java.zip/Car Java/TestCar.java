/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

/**
 *
 * @author Dubem
 */
public class TestCar {
    double Price;
    //Method to calculate price
    public static void calculatePrice(String Make, String Model,int Year,int Miles,double Mrsp) {
        //Current price of car
        double Price = Mrsp - ((Miles/250.0)*Mrsp);
        System.out.println("A "+ Year + " " + Make + " "+ Model + " with "+ Mrsp+ "$ mrsp driven for " + Miles + " miles sells for " + "$" + Price);
    }
    public static void main(String[] args) {
        Car second = new Car();

        Car first = new Car("Chevrolet","Camaro",2016,50,24500.0);
        
       second.setMake("Toyota");
       second.setModel("RAV4");
       second.setYear(2012);
       second.setMiles(130);
       second.setMrsp(22500.0);
       
       calculatePrice(first.getMake(),first.getModel(),first.getYear(),first.getMiles(),first.getMrsp());

       calculatePrice(second.getMake(),second.getModel(),second.getYear(),second.getMiles(),second.getMrsp());

    }
}
