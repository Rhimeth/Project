/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

import java.util.Scanner;

//Declaring specified variables
public class Car {
        String Make;
        String Model;
        int Year;
        int Miles;
        double Mrsp;
        
        //Default constructor setting default vales
        public Car() {
            this.Make = "Cjevrolet";
            this.Model = "Camaro";
            this.Year = 2016;
            this.Miles = 50;
            double Mrsp = 24500.0;
        }
        
        
        //Getter and Setter Methods for all the variable 
        public String getMake() {
            return Make;
        }
    
        public void setMake(String Make) {
            this.Make = Make;
        }
    
        public String getModel() {
            return Model;
        }
    
        public void setModel(String Model) {
            this.Model = Model;
        }
    
        public int getYear() {
            return Year;
        }
    
        public void setYear(int Year) {
            this.Year = Year;
        }
    
        public int getMiles() {
        return Year;
        }
    
        public void setMiles(int Miles) {
            this.Miles = Miles;
        }
    
        public double getMrsp() {
            return Mrsp;
        }
    

        public void setMrsp(double Mrsp) {
        this.Mrsp = Mrsp;
    }
    
    //Argumented constructor to set values
    public Car(String Make,String Model,int Year,int Miles,double Msrp) { 
        this.Make = Make;
        this.Model = Model;
        this.Year = Year;
        this.Miles = Miles;
        this.Mrsp = Mrsp;
    }  
}
